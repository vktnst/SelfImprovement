function search() {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const searchResults = document.getElementById('searchResults');
    searchResults.innerHTML = '';

    // Вашите данни, които ще се търсят (може да са в масив, обект и т.н.)
    const data = [
        'This book explores the fascinating science behind habits, delving into how they are formed and how they can be changed. Duhigg provides real-life examples and case studies, illustrating how habits shape individual and organizational behavior. By understanding the cues, routines, and rewards that drive habits, readers can learn to identify and modify their own habits for personal growth and success.',
        'Clears book emphasizes the idea that small changes, when compounded over time, can lead to significant improvements. He introduces the concept of "atomic habits," which are tiny, incremental changes that ultimately result in transformative outcomes. With practical strategies and actionable advice, Clear shows readers how to build good habits, break bad ones, and optimize their daily routines for maximum productivity and fulfillment.',
        'Dwecks research on fixed versus growth mindsets has had a profound impact on the fields of psychology and education. In her book, she explains how adopting a growth mindset—believing that abilities and intelligence can be developed through effort and learning—can unlock ones full potential. By cultivating a growth mindset, individuals are more resilient in the face of challenges and more motivated to pursue their goals with determination.',
        'Regarded as one of the most influential self-help books of all time, Carnegies classic offers timeless advice on building strong interpersonal relationships. Through practical tips and relatable anecdotes, Carnegie teaches readers how to communicate effectively, become genuinely interested in others, and win people over to their way of thinking. These principles are essential not only for personal success but also for professional advancement and leadership development.',
        'Coveys seminal work presents a holistic approach to personal and professional effectiveness based on timeless principles. By focusing on habits such as being proactive, beginning with the end in mind, and seeking first to understand, readers can cultivate a mindset of continuous improvement and synergy. Coveys framework encourages readers to align their actions with their values and goals, leading to greater fulfillment and success in all areas of life.',
        'Throughout their careers, individuals may undergo transitions such as changing jobs, industries, or roles. These transitions can be prompted by factors such as personal growth, economic conditions, or shifts in the labor market. Successfully navigating career transitions often requires adaptability, resilience, and a willingness to learn.',
        'Achieving a balance between work and personal life is essential for overall well-being and career satisfaction. Balancing responsibilities at work with family, hobbies, and other interests can contribute to increased productivity, reduced stress, and greater fulfillment in both professional and personal domains.',
        'Advancing in ones career typically involves progressing to higher levels of responsibility, authority, and compensation. This may entail seeking promotions within an organization, pursuing opportunities for professional development, or transitioning to new roles with greater challenges and rewards.',
        ' Ultimately, career satisfaction stems from finding fulfillment and meaning in ones work. This can be influenced by factors such as alignment with personal values, opportunities for growth and development, positive relationships with colleagues, and a sense of accomplishment in achieving professional goals.',
        'In todays rapidly changing work environment, continuous learning and adaptation are essential for staying relevant and competitive in ones career. This involves staying abreast of industry developments, acquiring new skills as needed, and being open to new opportunities and challenges.',
        'Fats, also known as lipids, are an important source of energy and provide the body with essential fatty acids that it cannot produce on its owwn.',
        ' Dietary fats are classified into several types, including saturated fats, unsaturated fats (monounsaturated and polyunsaturated), and trans fats.',
        ' Unsaturated fats, found in foods such as nuts, seeds, avocados, and olive oil, are considered heart-healthy and should be prioritized in the diet.',
        'While fats have often been vilified in the past, they play crucial roles in cell membrane structure, hormone production, vitamin absorption (such as vitamins A, D, E, and K), and insulation and protection of organs.',
        'Consuming excessive amounts of saturated and trans fats, commonly found in processed and fried foods, can increase the risk of heart disease and other health problems. Therefore, it is important to focus on consuming healthy fats in moderation as part of a balanced diet.',
        ' Carbohydrates are the bodys primary source of energy and are found in foods such as grains, fruits, vegetables, legumes, and dairy products.',

       ' Carbohydrates are classified into three main types: sugars, starches, and fiber. Simple carbohydrates, such as those found in candy, soda, and baked goods, are quickly broken down into sugar and provide a rapid source of energy. Complex carbohydrates, found in whole grains, vegetables, and legumes, are digested more slowly, providing sustained energy and promoting feelings of fullness.',

 'Fiber, a type of carbohydrate found in plant-based foods, is important for digestive health, regulating blood sugar levels, and reducing the risk of chronic diseases such as heart disease and type 2 diabetes.',

 'While carbohydrates are a vital part of a healthy diet, consuming too many refined carbohydrates and sugars can contribute to weight gain, insulin resistance, and an increased risk of chronic diseases. Choosing whole, minimally processed carbohydrates and balancing carbohydrate intake with protein and fats is key to maintaining optimal health. Carbohydrates are the bodys primary source of energy and are found in foods such as grains, fruits, vegetables, legumes, and dairy products.',
 'Carbohydrates are classified into three main types: sugars, starches, and fiber. Simple carbohydrates, such as those found in candy, soda, and baked goods, are quickly broken down into sugar and provide a rapid source of energy. Complex carbohydrates, found in whole grains, vegetables, and legumes, are digested more slowly, providing sustained energy and promoting feelings of fullness.',

 'Fiber, a type of carbohydrate found in plant-based foods, is important for digestive health, regulating blood sugar levels, and reducing the risk of chronic diseases such as heart disease and type 2 diabetes.',

 'While carbohydrates are a vital part of a healthy diet, consuming too many refined carbohydrates and sugars can contribute to weight gain, insulin resistance, and an increased risk of chronic diseases. Choosing whole, minimally processed carbohydrates and balancing carbohydrate intake with protein and fats is key to maintaining optimal health.',
     
 'Proteins are essential for building and repairing tissues, synthesizing hormones and enzymes, and supporting immune function.',
 'Dietary proteins are composed of amino acids, often referred to as the building blocks of protein. While the body can produce some amino acids on its own, others, known as essential amino acids, must be obtained from the diet.',
 'Complete proteins, found in animal products such as meat, fish, poultry, eggs, and dairy, contain all nine essential amino acids in adequate amounts. Plant-based sources of protein, such as beans, lentils, tofu, tempeh, quinoa, and nuts, can also provide all essential amino acids when consumed in combination.',
 'Consuming an adequate amount of protein is important for maintaining muscle mass, promoting satiety and weight management, and supporting overall health. However, excessive protein intake can strain the kidneys and may be detrimental to individuals with certain kidney conditions.',

 'It is recommended to include a variety of protein sources in the diet and to balance protein intake with carbohydrates and fats for optimal health and nutrition.',
 ' Cardiorespiratory Endurance: The ability of the heart, lungs, and circulatory system to deliver oxygen to the bodys  tissues during sustained physical activity.',
 'Muscular Strength: The amount of force a muscle or muscle group can exert against resistance.',
 'Muscular Endurance: The ability of muscles to perform repetitive contractions over an extended period.',
 'Flexibility: The range of motion around a joint or group of joints.',
 'Body Composition: The proportion of fat, muscle, and other tissues in the body.',
 'Benefits of Fitness',
 'Improved Cardiovascular Health: Exercise strengthens the heart and improves circulation, reducing the risk of heart disease, stroke, and high blood pressure.',
 'Enhanced Muscular Strength and Endurance: Strength training exercises increase muscle mass, bone density, and overall strength, reducing the risk of injury and promoting functional independence.',
 'Increased Flexibility and Joint Health: Stretching exercises improve flexibility, reduce muscle stiffness, and enhance joint range of motion, reducing the risk of injury and improving posture.',
 'Weight Management: Physical activity helps burn calories and maintain a healthy body weight, reducing the risk of obesity and associated health problems.',
 'Mood Enhancement: Exercise releases endorphins, neurotransmitters that promote feelings of happiness and well-being, reducing stress, anxiety, and depression.',
 'Improved Sleep Quality: Regular physical activity can help regulate sleep patterns, improve sleep quality, and reduce the incidence of sleep disorders.',
 'Types of Fitness Activities',
 ' Cardiovascular Exercise: Activities such as walking, running, cycling, swimming, and dancing that elevate the heart rate and improve cardiovascular fitness.',
 'Strength Training: Exercises using resistance, such as weightlifting, bodyweight exercises, and resistance band workouts, to build muscular strength and endurance.',
 ' Flexibility Training: Stretching exercises, yoga, and Pilates that improve flexibility, mobility, and joint health.',
 ' Functional Fitness: Activities that mimic real-life movements and improve balance, coordination, and agility, such as functional training, balance exercises, and agility drills.',
 'Mind-Body Practices: Activities such as yoga, tai chi, and qigong that integrate physical movement with mindfulness, promoting relaxation, stress reduction, and overall well-being.',
 'Setting Fitness Goals',
 'Establishing clear, achievable fitness goals is essential for staying motivated and tracking progress.',
 'Goals should be specific, measurable, attainable, relevant, and time-bound (SMART), and tailored to individual preferences, abilities, and interests.',
 'Tracking progress, celebrating successes, and adjusting goals as needed are important for maintaining motivation and momentum.',
 'Incorporating Fitness into Daily Life',
 'Making physical activity and exercise a regular part of daily life is key to achieving and maintaining fitness.',
 'Incorporating activities such as walking or cycling for transportation, taking the stairs instead of the elevator, and participating in recreational sports or group fitness classes can help increase overall activity levels.',
 ' Finding activities that are enjoyable, social, and convenient increases the likelihood of adherence and long-term success.',
 ' Habits are formed through repetition and reinforcement. When we repeatedly engage in a behavior in a particular context or environment, our brains create neural pathways that make the behavior more automatic and less reliant on conscious effort.',
 'The habit loop, as described by Charles Duhigg in "The Power of Habit," consists of three components: cue, routine, and reward. The cue triggers the habit, the routine is the behavior itself, and the reward is the positive reinforcement that reinforces the habit loop.',
 'These are routines and behaviors that we engage in on a daily basis, such as brushing teeth, exercising, or checking emails.',
 'Productive Habits: These are behaviors that contribute to personal or professional growth and productivity, such as goal setting, time management, and lifelong learning.',
 'Habits of Mind: These are mental habits or patterns of thinking, such as optimism, resilience, and mindfulness, that influence our attitudes and perceptions.',
 ' Habits of Behavior: These are actions and behaviors that reflect our values, beliefs, and character, such as honesty, integrity, and kindness.',
 'Improved productivity and efficiency in daily tasks and responsibilities.',
 ' Enhanced physical and mental health, as certain habits such as exercise, healthy eating, and stress management contribute to overall well-being.',
 ' Increased self-discipline and self-control, as habits help automate decision-making processes and conserve mental energy.',
 'Greater success and achievement in personal and professional endeavors, as productive habits foster goal attainment and continuous improvement.',
 ' While habits are often deeply ingrained and difficult to break, it is possible to change them through conscious effort and practice.',
 ' The process of habit change typically involves identifying the cue and reward associated with a habit, replacing the routine with a more desirable behavior, and reinforcing the new habit through repetition and positive reinforcement.',
 'Strategies for changing habits include setting specific, achievable goals, creating an environment that supports the desired behavior, and leveraging social support and accountability.',
 'Maintaining ',
 'Consistency is key to maintaining habits over time. By committing to daily practice and persevering through setbacks and challenges, individuals can solidify new habits and make them more automatic.',
 'Monitoring progress, tracking successes, and celebrating milestones can help reinforce positive habits and sustain motivation.',
 'Flexibility and adaptability are also important for maintaining habits in the face of changing circumstances or priorities. Adjusting routines and strategies as needed allows individuals to stay on track and continue progressing toward their goals.',
 ' Brushing teeth twice a day with fluoride toothpaste, flossing daily to remove plaque and food particles between teeth, and visiting the dentist regularly for check-ups and cleanings are important components of oral hygiene',
 'Bathing or showering regularly helps remove sweat, dirt, and dead skin cells from the skin, reducing the risk of skin infections and body odor',
 'Using soap and water to cleanse the body, paying attention to areas prone to sweat and odor, and drying off thoroughly after bathing are important for maintaining good body hygiene',
 'Environmental hygiene involves keeping living and working spaces clean and sanitary to prevent the spread of germs and contaminants.',
 'This includes practices such as regularly cleaning and disinfecting surfaces, maintaining proper ventilation, and ensuring the safe handling and disposal of waste.',
 'Food hygiene refers to practices that ensure the safety and cleanliness of food from preparation to consumption.',
 'This includes washing hands before handling food, keeping food preparation surfaces clean, cooking food to the appropriate temperature to kill bacteria, and storing perishable foods properly to prevent spoilage.',
 'Public health measures such as vaccination, disease surveillance, and sanitation infrastructure play a crucial role in preventing the spread of infectious diseases within communities.',
 'Access to clean drinking water, proper waste disposal systems, and sanitary facilities such as toilets and handwashing stations are essential for promoting public health and hygiene.',
 'In conclusion, practicing good hygiene is essential for maintaining health and preventing the spread of illness and disease. By incorporating simple hygiene habits into daily routines and promoting hygiene practices at the community level, individuals can contribute to a cleaner, healthier environment for themselves and others.',
 'Sleep is essential for overall health, playing a critical role in physical, mental, and emotional well-being.',
 'It is during sleep that the body repairs tissues, synthesizes hormones, consolidates memories, and regulates various bodily functions.',
 ' Sleep is divided into two main categories: rapid eye movement (REM) sleep and non-rapid eye movement (NREM) sleep.',
 ' NREM sleep consists of three stages: N1, N2, and N3. N1 is the transition stage between wakefulness and sleep, N2 is a light sleep stage, and N3 is deep sleep, also known as slow-wave sleep.',
 ' REM sleep is characterized by rapid eye movements, vivid dreaming, and physiological changes such as increased heart rate and irregular breathing.',
 'Sleep typically occurs in cycles, with each cycle consisting of alternating REM and NREM stages.',
 ' A complete sleep cycle lasts approximately 90 minutes, with individuals experiencing multiple cycles throughout the night.',
 ' Various factors can affect the quality and duration of sleep, including environmental factors (such as noise, light, and temperature), lifestyle habits (such as caffeine consumption, exercise, and screen time), and medical conditions (such as sleep disorders, chronic pain, and mental health issues).',
 ' Additionally, stress, anxiety, and certain medications can interfere with sleep quality and quantity.',
 'Adequate sleep is associated with numerous health benefits, including improved cognitive function, memory consolidation, mood regulation, immune function, and metabolism.',
 'Chronic sleep deprivation, on the other hand, has been linked to an increased risk of obesity, diabetes, heart disease, depression, and other health problems.',
 'Establishing a regular sleep schedule and bedtime routine can help regulate the bodys internal clock and improve sleep quality.',
 ' Creating a comfortable sleep environment by minimizing noise, light, and temperature disruptions can promote restful sleep.',
 'Avoiding stimulants such as caffeine and electronic devices close to bedtime can help signal the body to wind down and prepare for sleep.',
 ' Practicing relaxation techniques such as deep breathing, meditation, or gentle stretching before bed can help reduce stress and promote relaxation.',
 'Individuals experiencing chronic sleep disturbances or symptoms of sleep disorders, such as insomnia, sleep apnea, or restless legs syndrome, should consult a healthcare professional for evaluation and treatment options.',
 'Sleep disorders can have significant impacts on physical and mental health, and addressing them is essential for overall well-being.',


]

    // Прохождане през данните и проверка за съвпадения
    data.forEach(item => {
        if (item.toLowerCase().includes(searchInput)) {
            const li = document.createElement('li');
            li.textContent = item;
            searchResults.appendChild(li);
        }
    });

    if (searchResults.children.length === 0) {
        const li = document.createElement('li');
        li.textContent = 'No results found';
        searchResults.appendChild(li);
    }
}
